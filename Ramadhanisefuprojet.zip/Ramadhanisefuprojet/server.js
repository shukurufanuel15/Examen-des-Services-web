const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const path = require('path');
const stripe = require('stripe')('sk_test_51QRrtvJemyrDvvPRTvkalRPtGbo8Q3WdN7OGAtt8P7BUd8iCJfSrQksuUwbcbSuHNJu3GEjKtMNqcbNoVMcRUoOA00Xqsp06Sz'); // Votre clé secrète Stripe

const app = express();
const port = 3000;

// Remplacez par vos informations Twilio
const accountSid = 'AC007413584e7df3f1dcfcb93011b97ebc'; // Votre Account SID
const authToken = '3a9ffad7d79acae20cc0b0dfd72b0723'; // Votre Auth Token
const twilioNumber = '+17755875506'; // Votre numéro Twilio

const client = new twilio(accountSid, authToken);

// Middleware pour parser le JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname)); // Spécifie le dossier courant pour les fichiers statiques

// Route pour servir le fichier SMS HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'sms.html')); // Envoie le fichier sms.html dans le même dossier
});

// Endpoint pour envoyer un SMS
app.post('/send-sms', (req, res) => {
    const { to, message } = req.body;

    // Vérifiez que les champs ne sont pas vides
    if (!to || !message) {
        return res.status(400).json({ status: 'Erreur : numéro de téléphone ou message manquant.' });
    }

    client.messages.create({
        body: message,
        from: twilioNumber,
        to: to
    })
    .then(message => {
        console.log(`Message SID: ${message.sid}`);
        res.json({ status: `Message envoyé avec succès : ${message.sid}` });
    })
    .catch(error => {
        console.error(`Erreur d'envoi : ${error.message}`);
        res.status(500).json({ status: 'Erreur lors de l\'envoi du message.' });    
    });
});

// Route pour créer une session de paiement Checkout
app.post('/create-checkout-session', async (req, res) => {
    const { amount, currency } = req.body;

    try {
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [{
                price_data: {
                    currency: currency,
                    product_data: {
                        name: 'Montant de paiement',
                    },
                    unit_amount: amount, // Montant en cents
                },
                quantity: 1,
            }],
            mode: 'payment',
            success_url: 'http://localhost:3000/success.html', // Remplacez par votre URL de succès
            cancel_url: 'http://localhost:3000/cancel.html', // Remplacez par votre URL d'annulation
        });

        res.json({ id: session.id });
    } catch (error) {
        console.error(`Erreur lors de la création de la session Checkout : ${error.message}`);
        res.status(500).send({ error: 'Erreur lors de la création de la session de paiement.' });
    }
});

// Démarrer le serveur
app.listen(port, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${port}`);
});